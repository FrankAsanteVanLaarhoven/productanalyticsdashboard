from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from datetime import datetime, timedelta
import pandas as pd
import kagglehub
import os
import logging

def get_postgres_conn():
    from sqlalchemy import create_engine
    return create_engine('postgresql://airflow:airflow@postgres/airflow')

def extract_sales_data(**context):
    """Extract data from Kaggle with detailed logging"""
    logging.info("Starting data extraction...")
    
    try:
        # Download dataset
        path = kagglehub.dataset_download(
            "thedevastator/unlock-profits-with-e-commerce-sales-data"
        )
        logging.info(f"Dataset downloaded to: {path}")
        
        # List files
        files = os.listdir(path)
        logging.info(f"Files in directory: {files}")
        
        # Find CSV file
        csv_files = [f for f in files if f.endswith('.csv')]
        if not csv_files:
            raise FileNotFoundError("No CSV files found")
            
        file_path = os.path.join(path, csv_files[0])
        logging.info(f"Using file: {file_path}")
        
        # Read data
        df = pd.read_csv(file_path)
        logging.info(f"Read {len(df)} records from CSV")
        
        # Store raw data
        context['task_instance'].xcom_push(key='raw_sales_data', value=df.to_dict())
        return f"Extracted {len(df)} records"
        
    except Exception as e:
        logging.error(f"Extraction failed: {str(e)}")
        raise

def transform_sales_data(**context):
    """Transform sales data with logging"""
    logging.info("Starting data transformation...")
    
    try:
        # Get raw data
        raw_data = context['task_instance'].xcom_pull(key='raw_sales_data')
        df = pd.DataFrame(raw_data)
        logging.info(f"Retrieved {len(df)} raw records")
        
        # Basic transformations
        df['sale_date'] = datetime.now().date()
        df['category'] = df['Style Id'].str.split('_').str[0]
        df['sku'] = df['Sku']
        df['status'] = 'Active'
        df['fulfillment'] = 'Marketplace'
        df['style_id'] = df['Style Id']
        df['courier_status'] = 'Pending'
        df['quantity'] = 1
        df['amount'] = df['Myntra MRP']
        df['is_b2b'] = False
        df['currency'] = 'INR'
        df['amount_usd'] = df['amount'] / 83.0
        
        logging.info("Transformations applied")
        logging.info(f"Columns after transform: {df.columns.tolist()}")
        
        # Select final columns
        final_columns = [
            'category', 'sku', 'sale_date', 'status', 'fulfillment',
            'style_id', 'courier_status', 'quantity', 'amount',
            'is_b2b', 'currency', 'amount_usd'
        ]
        
        df = df[final_columns]
        logging.info(f"Final dataset has {len(df)} records")
        
        # Store transformed data
        context['task_instance'].xcom_push(key='transformed_sales_data', value=df.to_dict())
        return f"Transformed {len(df)} records"
        
    except Exception as e:
        logging.error(f"Transformation failed: {str(e)}")
        raise

def load_sales_data(**context):
    """Load data to PostgreSQL with logging"""
    logging.info("Starting data load...")
    
    try:
        # Get transformed data
        transformed_data = context['task_instance'].xcom_pull(key='transformed_sales_data')
        df = pd.DataFrame(transformed_data)
        logging.info(f"Retrieved {len(df)} transformed records")
        
        # Get database connection
        engine = get_postgres_conn()
        logging.info("Database connection established")
        
        # Load data
        df.to_sql(
            'amazon_sales',
            engine,
            schema='meap',
            if_exists='append',
            index=False
        )
        logging.info(f"Loaded {len(df)} records to database")
        
        # Verify load
        result = pd.read_sql(
            "SELECT COUNT(*) as count FROM meap.amazon_sales",
            engine
        )
        logging.info(f"Total records in database: {result['count'].iloc[0]}")
        
        return f"Loaded {len(df)} records successfully"
        
    except Exception as e:
        logging.error(f"Load failed: {str(e)}")
        raise

default_args = {
    'owner': 'favl',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'email': ['info@frankvanlaarhoven.co.uk'],
    'email_on_failure': True,
    'retries': 1,
    'retry_delay': timedelta(minutes=5)
}

with DAG(
    'amazon_sales_etl',
    default_args=default_args,
    description='ETL pipeline for Kaggle e-commerce sales data',
    schedule_interval='@daily',
    catchup=False
) as dag:

    create_tables = PostgresOperator(
        task_id='create_tables',
        postgres_conn_id='postgres_default',
        sql="""
        CREATE SCHEMA IF NOT EXISTS meap;
        
        CREATE TABLE IF NOT EXISTS meap.amazon_sales (
            id SERIAL PRIMARY KEY,
            category VARCHAR(100),
            sku VARCHAR(100),
            sale_date DATE,
            status VARCHAR(50),
            fulfillment VARCHAR(100),
            style_id VARCHAR(100),
            courier_status VARCHAR(50),
            quantity INTEGER,
            amount DECIMAL(10,2),
            is_b2b BOOLEAN,
            currency VARCHAR(3),
            amount_usd DECIMAL(10,2),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """
    )

    extract_task = PythonOperator(
        task_id='extract_sales_data',
        python_callable=extract_sales_data
    )

    transform_task = PythonOperator(
        task_id='transform_sales_data',
        python_callable=transform_sales_data
    )

    load_task = PythonOperator(
        task_id='load_sales_data',
        python_callable=load_sales_data
    )

    create_tables >> extract_task >> transform_task >> load_task
