from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
import kagglehub
import pandas as pd
import os
import logging

def test_kaggle_download(**context):
    logging.info("Starting Kaggle dataset download test...")
    
    try:
        # Download dataset
        path = kagglehub.dataset_download(
            "thedevastator/unlock-profits-with-e-commerce-sales-data"
        )
        logging.info(f"Dataset downloaded to: {path}")
        
        # List files in directory
        files = os.listdir(path)
        logging.info(f"Files in directory: {files}")
        
        # Find CSV file
        csv_files = [f for f in files if f.endswith('.csv')]
        if not csv_files:
            raise FileNotFoundError("No CSV files found in dataset")
            
        # Read first CSV file
        csv_path = os.path.join(path, csv_files[0])
        df = pd.read_csv(csv_path)
        
        logging.info(f"\nDataset Preview:")
        logging.info(f"Total Records: {len(df)}")
        logging.info(f"Columns: {df.columns.tolist()}")
        logging.info(f"\nFirst 5 rows:")
        logging.info(df.head())
        
        return "Kaggle download test completed successfully"
        
    except Exception as e:
        logging.error(f"Test failed: {str(e)}")
        raise

default_args = {
    'owner': 'favl',
    'start_date': datetime(2024, 1, 1),
    'depends_on_past': False
}

with DAG(
    'test_kaggle_load',
    default_args=default_args,
    description='Test Kaggle Dataset Loading',
    schedule_interval=None,
    catchup=False
) as dag:

    test_task = PythonOperator(
        task_id='test_kaggle_download',
        python_callable=test_kaggle_download
    )
